import React from 'react';
import '../common.css';
import About from './about';

class AboutBody extends React.Component {
    render() {
        return (
            <About />
        );
    }
}

export default AboutBody;
