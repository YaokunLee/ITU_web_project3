import React from 'react';
import '../common.css';
import LoginForm from "./LoginForm";

class LoginBody extends React.Component {
    render() {
        return (
            <LoginForm/>
        );
    }
}

export default LoginBody;
