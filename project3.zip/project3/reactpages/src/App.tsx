import React from 'react';
import './index.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import PageWrapper from "./PageWrapper";

export class Root extends React.Component{
  render() {
    return (
        <PageWrapper/>
    );
  }
}
