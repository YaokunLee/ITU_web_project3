import React from 'react';
import '../common.css';
import ContactForm from './ContactForm';

class ContactBody extends React.Component {
    render(){
        return (
            <ContactForm />
        );
    }
}

export default ContactBody;
