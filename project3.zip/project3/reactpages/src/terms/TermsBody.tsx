import React from 'react';
import '../common.css';
import Terms from './terms';

class TermsBody extends React.Component {

    render () {
        return (
            <Terms/>
        );
    }
}

export default TermsBody;